# sugaai-pro
Full-stack Smart Agriculture App for Sugarcane Monitoring (AI + Firebase + ESP32)
